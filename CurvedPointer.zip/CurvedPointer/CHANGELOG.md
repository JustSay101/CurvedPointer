# Changelog

## [0.9.0] - 2022-09-09
### Added
- Necessary scripts for the pointer functionality added.
- Example scene added with example logic for updating the pointer during runtime.
- Pointer package created and functioning.